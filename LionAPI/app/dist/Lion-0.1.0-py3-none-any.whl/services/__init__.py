# app/services/__init__.py

from .database import query_events