# Soccer Data API

A FastAPI-based soccer data API that allows you to query soccer events from the Big 5 leagues.

## Installation

```bash
pip install -e .